// BankingProject.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	float initInv, monDep, anuInt, totalAm, intAm, yearToInt; //defining all the needed variables that require a float
	int month, years; //defining the int variables

	//Displaying data input form to user
	cout<< "********************************\n";
	cout << "********** Data Input **********\n";
	cout << "Initial Investment Amount: \n";
	cout << "Monthly Deposit: \n";
	cout << "Annual Interest: \n";
	cout << "Number of years: \n";

	system("PAUSE"); //waits for the user input

	//Takes the user input and stores the values
	cout << "********************************\n";
	cout << "********** Data Input **********\n";
	cout << "Initial Investment Amount: $";
	cin >> initInv;
	cout << "Monthly Deposit: $";
	cin >> monDep;
	cout << "Annual Interest: %";
	cin >> anuInt;
	cout << "Number of years: ";
	cin >> years;
	month = years * 12;

	system("PAUSE"); //waits for the user input

	totalAm = initInv; //sets the total ammount

	//Will display year data with no monthly deposits
	cout << "\nBalance and Interest Without Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";

	for (int i = 0; i < years; i++) {
		intAm = (totalAm) * (anuInt / 100); //Calculate yearly interest
		//cout << intAm; //Left over from debugging
		totalAm = totalAm + intAm; //Calculates the end of year total
		cout << (i + 1) << "\t\tS" << fixed << setprecision(2) << totalAm << "\t\t\tS" << intAm << "\n";
	}

	totalAm = initInv; //Updates total amount
	
	//Display year data while including monthly deposits
	cout << "\n\nBalance and Interest With Additional Monthly Deposits\n";
	cout << "==============================================================\n";
	cout << "Year\t\tYear End Balance\tYear End Earned Interest\n";
	cout << "--------------------------------------------------------------\n";


	for (int i = 0; i < years; i++) {
		yearToInt = 0; //makes the yearly intrest 0 at the start of the year
		for (int j = 0; j < 12; j++) {
			intAm = (totalAm + monDep) * ((anuInt / 100) / 12); //used to calculate monthly interest
			yearToInt = yearToInt + intAm; //Calculates Month end Interest
			totalAm = totalAm + monDep + intAm; //Calculates Month End Total
		}
		//Print results to the table using only two decimal points
		cout << (i + 1) << "\t\tS" << fixed << setprecision(2) << totalAm << "\t\t\tS" << yearToInt << "\n";
	}

	return 0;
}